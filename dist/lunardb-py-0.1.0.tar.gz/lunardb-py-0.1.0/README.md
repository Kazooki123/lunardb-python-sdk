# LunarDB Python Package SDK

A Package SDK for the LunarDB database. Making LunarDB accessible for
Python developers in the **Open Source Community!**

## Installation

**Python 3.9, 3.10** and above required

Run this command to install the `lunardb-py` sdk package:

```bash
pip install lunardb-py
